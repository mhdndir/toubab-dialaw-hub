import {
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  query,
  orderBy,
  serverTimestamp,
  arrayUnion,
  onSnapshot,
  Unsubscribe,
  Timestamp,
} from 'firebase/firestore';
import { v4 as uuidv4 } from 'uuid';
import { db } from '@/lib/firebase';
import type { Sondage, SondageFormData, SondageOption } from '@/lib/types';

const COLLECTION = 'sondages';

// ─── Create ────────────────────────────────────────────────────────────────

export async function createSondage(
  data: SondageFormData,
  authorId: string,
  authorName: string
): Promise<string> {
  const options: SondageOption[] = data.options.map(label => ({
    id:    uuidv4(),
    label,
    votes: [],
  }));

  const docRef = await addDoc(collection(db, COLLECTION), {
    question:    data.question,
    description: data.description ?? null,
    options,
    authorId,
    authorName,
    endsAt:   Timestamp.fromDate(data.endsAt),
    actif:    true,
    createdAt: serverTimestamp(),
  });

  return docRef.id;
}

// ─── Real-time subscription ────────────────────────────────────────────────

export function subscribeToSondages(
  callback: (sondages: Sondage[]) => void
): Unsubscribe {
  const q = query(collection(db, COLLECTION), orderBy('createdAt', 'desc'));

  return onSnapshot(q, snap => {
    const sondages = snap.docs.map(d => ({ id: d.id, ...d.data() } as Sondage));
    callback(sondages);
  });
}

// ─── Vote ─────────────────────────────────────────────────────────────────

export async function vote(
  sondageId: string,
  optionId: string,
  userId: string,
  allOptions: SondageOption[]
): Promise<void> {
  // Check user hasn't already voted
  const hasVoted = allOptions.some(o => o.votes.includes(userId));
  if (hasVoted) throw new Error('Vous avez déjà voté pour ce sondage.');

  const docRef = doc(db, COLLECTION, sondageId);
  const updatedOptions = allOptions.map(o =>
    o.id === optionId
      ? { ...o, votes: [...o.votes, userId] }
      : o
  );

  await updateDoc(docRef, { options: updatedOptions });
}

// ─── Toggle actif ──────────────────────────────────────────────────────────

export async function toggleSondage(id: string, actif: boolean): Promise<void> {
  await updateDoc(doc(db, COLLECTION, id), { actif });
}

// ─── Delete ────────────────────────────────────────────────────────────────

export async function deleteSondage(id: string): Promise<void> {
  await deleteDoc(doc(db, COLLECTION, id));
}
