'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { RiFilterLine, RiCloseLine } from 'react-icons/ri';
import type { AnnonceFilters, Annonce } from '@/lib/types';

const TYPES: { value: Annonce['type'] | ''; label: string }[] = [
  { value: '',            label: 'Tous'        },
  { value: 'terrain',     label: 'Terrains'    },
  { value: 'maison',      label: 'Maisons'     },
  { value: 'appartement', label: 'Appartements'},
  { value: 'service',     label: 'Services'    },
  { value: 'commerce',    label: 'Commerces'   },
];

interface FiltersProps {
  onChange: (filters: AnnonceFilters) => void;
}

export default function AnnonceFiltersBar({ onChange }: FiltersProps) {
  const [type,     setType]     = useState<Annonce['type'] | ''>('');
  const [prixMax,  setPrixMax]  = useState('');
  const [surfMin,  setSurfMin]  = useState('');
  const [expanded, setExpanded] = useState(false);

  const applyFilters = (t = type, pm = prixMax, sm = surfMin) => {
    onChange({
      type:       t || undefined,
      prixMax:    pm ? Number(pm) : undefined,
      surfaceMin: sm ? Number(sm) : undefined,
    });
  };

  const reset = () => {
    setType(''); setPrixMax(''); setSurfMin('');
    onChange({});
  };

  const hasFilters = type || prixMax || surfMin;

  return (
    <div className="glass border border-brand-border/60 rounded-2xl p-5 mb-8">
      {/* Type tabs */}
      <div className="flex flex-wrap gap-2 mb-4">
        {TYPES.map(t => (
          <button
            key={t.value}
            onClick={() => { setType(t.value); applyFilters(t.value); }}
            className={`px-4 py-2 rounded-xl text-xs font-mono font-medium border transition-all duration-200 ${
              type === t.value
                ? 'bg-brand-teal/10 border-brand-teal/40 text-brand-teal'
                : 'bg-brand-dark border-brand-border text-brand-muted hover:border-brand-muted hover:text-brand-light'
            }`}
          >
            {t.label}
          </button>
        ))}

        <button
          onClick={() => setExpanded(v => !v)}
          className="ml-auto flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-mono border border-brand-border text-brand-muted hover:border-brand-muted hover:text-brand-light transition-all"
        >
          <RiFilterLine size={14} />
          Plus de filtres
        </button>
      </div>

      {/* Advanced filters */}
      <motion.div
        initial={false}
        animate={{ height: expanded ? 'auto' : 0, opacity: expanded ? 1 : 0 }}
        transition={{ duration: 0.3, ease: 'easeInOut' }}
        className="overflow-hidden"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 pb-1">
          <div>
            <label className="label">Prix max (FCFA)</label>
            <input
              type="number"
              value={prixMax}
              onChange={e => setPrixMax(e.target.value)}
              onBlur={() => applyFilters()}
              placeholder="Ex: 5000000"
              className="input-field text-sm"
              min="0"
            />
          </div>
          <div>
            <label className="label">Surface min (m²)</label>
            <input
              type="number"
              value={surfMin}
              onChange={e => setSurfMin(e.target.value)}
              onBlur={() => applyFilters()}
              placeholder="Ex: 100"
              className="input-field text-sm"
              min="0"
            />
          </div>
        </div>
      </motion.div>

      {/* Reset */}
      {hasFilters && (
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          onClick={reset}
          className="flex items-center gap-1.5 text-xs text-brand-muted hover:text-red-400 transition-colors mt-3"
        >
          <RiCloseLine size={14} />
          Effacer les filtres
        </motion.button>
      )}
    </div>
  );
}
