import { Timestamp } from 'firebase/firestore';

// ─── Post (Publication) ────────────────────────────────────────────────────

export interface Post {
  id: string;
  title: string;
  content: string;
  imageUrl?: string;
  authorId: string;
  authorName: string;
  authorAvatar?: string;
  category: PostCategory;
  likes: string[];       // array of user IDs
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export type PostCategory = 'actualite' | 'evenement' | 'annonce' | 'communaute';

export interface PostFormData {
  title: string;
  content: string;
  image?: File;
  category: PostCategory;
}

// ─── Annonce (Marketplace) ─────────────────────────────────────────────────

export interface Annonce {
  id: string;
  title: string;
  description: string;
  prix: number;
  surface?: number;
  type: AnnonceType;
  images: string[];
  contact: string;
  authorId: string;
  authorName: string;
  localite: string;
  disponible: boolean;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export type AnnonceType = 'terrain' | 'maison' | 'appartement' | 'service' | 'commerce';

export interface AnnonceFormData {
  title: string;
  description: string;
  prix: number;
  surface?: number;
  type: AnnonceType;
  contact: string;
  localite: string;
  images?: FileList;
}

export interface AnnonceFilters {
  type?: AnnonceType | '';
  prixMin?: number;
  prixMax?: number;
  surfaceMin?: number;
}

// ─── Sondage (Poll) ────────────────────────────────────────────────────────

export interface SondageOption {
  id: string;
  label: string;
  votes: string[];  // array of user IDs
}

export interface Sondage {
  id: string;
  question: string;
  description?: string;
  options: SondageOption[];
  authorId: string;
  authorName: string;
  endsAt: Timestamp;
  actif: boolean;
  createdAt: Timestamp;
}

export interface SondageFormData {
  question: string;
  description?: string;
  options: string[];
  endsAt: Date;
}

// ─── User / Auth ───────────────────────────────────────────────────────────

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  isAdmin: boolean;
  createdAt: Timestamp;
}

// ─── Utility ───────────────────────────────────────────────────────────────

export type FirestoreCollection = 'posts' | 'annonces' | 'sondages' | 'users';
