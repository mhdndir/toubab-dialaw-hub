'use client';

import { useState } from 'react';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';
import {
  RiHeart3Line, RiHeart3Fill, RiDeleteBin6Line,
  RiEditLine, RiShareLine,
} from 'react-icons/ri';
import type { Post } from '@/lib/types';

const CATEGORY_LABELS: Record<Post['category'], string> = {
  actualite:  'Actualité',
  evenement:  'Événement',
  annonce:    'Annonce',
  communaute: 'Communauté',
};

const CATEGORY_COLORS: Record<Post['category'], string> = {
  actualite:  'text-blue-400 bg-blue-400/10 border-blue-400/20',
  evenement:  'text-brand-gold bg-brand-gold/10 border-brand-gold/20',
  annonce:    'text-brand-teal bg-brand-teal/10 border-brand-teal/20',
  communaute: 'text-purple-400 bg-purple-400/10 border-purple-400/20',
};

interface PostCardProps {
  post:      Post;
  userId?:   string;
  isAdmin?:  boolean;
  onLike?:   (postId: string, liked: boolean) => void;
  onDelete?: (postId: string, imageUrl?: string) => void;
  onEdit?:   (post: Post) => void;
}

export default function PostCard({
  post,
  userId,
  isAdmin,
  onLike,
  onDelete,
  onEdit,
}: PostCardProps) {
  const [imageError, setImageError] = useState(false);
  const liked   = userId ? post.likes.includes(userId) : false;
  const likeCount = post.likes.length;

  const timeAgo = post.createdAt
    ? formatDistanceToNow(post.createdAt.toDate(), { addSuffix: true, locale: fr })
    : '';

  const handleShare = async () => {
    if (navigator.share) {
      await navigator.share({ title: post.title, text: post.content });
    } else {
      navigator.clipboard.writeText(window.location.href);
    }
  };

  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      className="card card-hover group"
    >
      {/* Image */}
      {post.imageUrl && !imageError && (
        <div className="relative h-52 overflow-hidden">
          <Image
            src={post.imageUrl}
            alt={post.title}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-105"
            onError={() => setImageError(true)}
            sizes="(max-width: 768px) 100vw, 50vw"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-brand-dark/60 to-transparent" />

          {/* Category badge overlay */}
          <div className="absolute top-4 left-4">
            <span className={`px-3 py-1 rounded-full text-xs font-mono font-medium border glass ${CATEGORY_COLORS[post.category]}`}>
              {CATEGORY_LABELS[post.category]}
            </span>
          </div>
        </div>
      )}

      <div className="p-5">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 mb-4">
          <div className="flex items-center gap-3">
            {/* Avatar */}
            <div className="w-9 h-9 rounded-full bg-brand-teal/10 border border-brand-teal/20 flex items-center justify-center shrink-0">
              <span className="text-brand-teal font-display font-bold text-sm">
                {post.authorName.charAt(0).toUpperCase()}
              </span>
            </div>
            <div>
              <p className="text-white text-sm font-body font-medium leading-tight">{post.authorName}</p>
              <p className="text-brand-muted text-xs">{timeAgo}</p>
            </div>
          </div>

          {!post.imageUrl && (
            <span className={`px-3 py-1 rounded-full text-xs font-mono font-medium border ${CATEGORY_COLORS[post.category]} shrink-0`}>
              {CATEGORY_LABELS[post.category]}
            </span>
          )}
        </div>

        {/* Content */}
        <h3 className="font-display font-bold text-lg text-white mb-2 leading-snug">
          {post.title}
        </h3>
        <p className="text-brand-muted text-sm leading-relaxed line-clamp-3 mb-4">
          {post.content}
        </p>

        {/* Actions */}
        <div className="flex items-center justify-between pt-4 border-t border-brand-border/40">
          <div className="flex items-center gap-1">
            {/* Like */}
            <motion.button
              whileTap={{ scale: 0.85 }}
              onClick={() => userId && onLike?.(post.id, !liked)}
              disabled={!userId}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all duration-200 hover:bg-brand-border/40 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {liked
                ? <RiHeart3Fill className="text-red-400 text-base" />
                : <RiHeart3Line className="text-brand-muted text-base" />
              }
              <span className={`text-xs font-mono ${liked ? 'text-red-400' : 'text-brand-muted'}`}>
                {likeCount}
              </span>
            </motion.button>

            {/* Share */}
            <button
              onClick={handleShare}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-brand-muted hover:text-brand-teal hover:bg-brand-border/40 transition-all duration-200"
            >
              <RiShareLine className="text-base" />
            </button>
          </div>

          {/* Admin actions */}
          {isAdmin && (
            <div className="flex items-center gap-1">
              <button
                onClick={() => onEdit?.(post)}
                className="p-2 rounded-lg text-brand-muted hover:text-brand-gold hover:bg-brand-gold/10 transition-all"
              >
                <RiEditLine size={15} />
              </button>
              <button
                onClick={() => onDelete?.(post.id, post.imageUrl)}
                className="p-2 rounded-lg text-brand-muted hover:text-red-400 hover:bg-red-400/10 transition-all"
              >
                <RiDeleteBin6Line size={15} />
              </button>
            </div>
          )}
        </div>
      </div>
    </motion.article>
  );
}
