'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { formatDistanceToNow, isPast } from 'date-fns';
import { fr } from 'date-fns/locale';
import {
  RiBarChartBoxLine, RiTimeLine, RiDeleteBin6Line,
  RiCheckLine, RiLockLine,
} from 'react-icons/ri';
import toast from 'react-hot-toast';
import type { Sondage } from '@/lib/types';
import { vote } from '@/services/sondages';

interface SondageCardProps {
  sondage:   Sondage;
  userId?:   string;
  isAdmin?:  boolean;
  onDelete?: (id: string) => void;
  onToggle?: (id: string, actif: boolean) => void;
}

export default function SondageCard({
  sondage,
  userId,
  isAdmin,
  onDelete,
  onToggle,
}: SondageCardProps) {
  const [voting, setVoting] = useState(false);

  const totalVotes = sondage.options.reduce((sum, o) => sum + o.votes.length, 0);
  const userVoted  = userId ? sondage.options.some(o => o.votes.includes(userId)) : false;
  const expired    = isPast(sondage.endsAt.toDate());
  const showResults = userVoted || expired || !userId;

  const timeLabel = expired
    ? 'Terminé'
    : `Se termine ${formatDistanceToNow(sondage.endsAt.toDate(), { addSuffix: true, locale: fr })}`;

  const handleVote = async (optionId: string) => {
    if (!userId) { toast.error('Connectez-vous pour voter'); return; }
    if (userVoted) { toast.error('Vous avez déjà voté'); return; }
    if (expired)  { toast.error('Ce sondage est terminé'); return; }

    setVoting(true);
    try {
      await vote(sondage.id, optionId, userId, sondage.options);
      toast.success('Vote enregistré !');
    } catch (err: any) {
      toast.error(err.message ?? 'Erreur lors du vote');
    } finally {
      setVoting(false);
    }
  };

  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      className={`card card-hover p-6 ${(!sondage.actif || expired) ? 'opacity-70' : ''}`}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-4 mb-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-brand-teal/10 border border-brand-teal/20 flex items-center justify-center shrink-0">
            <RiBarChartBoxLine className="text-brand-teal text-sm" />
          </div>
          <span className="text-xs font-mono text-brand-muted">par {sondage.authorName}</span>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-brand-muted">
          {expired ? <RiLockLine className="text-red-400" /> : <RiTimeLine className="text-brand-teal" />}
          <span className={expired ? 'text-red-400' : ''}>{timeLabel}</span>
        </div>
      </div>

      {/* Question */}
      <h3 className="font-display font-bold text-lg text-white mb-1 leading-snug">
        {sondage.question}
      </h3>
      {sondage.description && (
        <p className="text-brand-muted text-sm mb-5">{sondage.description}</p>
      )}

      {/* Options */}
      <div className="space-y-3 mb-5">
        {sondage.options.map(option => {
          const optVotes  = option.votes.length;
          const pct       = totalVotes > 0 ? Math.round((optVotes / totalVotes) * 100) : 0;
          const isMyVote  = userId ? option.votes.includes(userId) : false;

          return (
            <div key={option.id}>
              {showResults ? (
                /* Result bar */
                <div className={`relative rounded-xl overflow-hidden border transition-colors ${
                  isMyVote ? 'border-brand-teal/40' : 'border-brand-border/60'
                }`}>
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${pct}%` }}
                    transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
                    className={`absolute inset-y-0 left-0 ${isMyVote ? 'bg-brand-teal/20' : 'bg-brand-border/30'}`}
                  />
                  <div className="relative flex items-center justify-between px-4 py-3">
                    <div className="flex items-center gap-2">
                      {isMyVote && <RiCheckLine className="text-brand-teal text-sm shrink-0" />}
                      <span className={`text-sm font-body ${isMyVote ? 'text-brand-teal' : 'text-brand-light'}`}>
                        {option.label}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-xs text-brand-muted font-mono">{optVotes}</span>
                      <span className={`text-sm font-mono font-bold ${isMyVote ? 'text-brand-teal' : 'text-white'}`}>
                        {pct}%
                      </span>
                    </div>
                  </div>
                </div>
              ) : (
                /* Vote button */
                <motion.button
                  whileHover={{ x: 4 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleVote(option.id)}
                  disabled={voting}
                  className="w-full text-left px-4 py-3 rounded-xl border border-brand-border/60 text-brand-light text-sm hover:border-brand-teal/40 hover:bg-brand-teal/5 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {option.label}
                </motion.button>
              )}
            </div>
          );
        })}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between pt-4 border-t border-brand-border/40">
        <span className="text-xs text-brand-muted font-mono">
          {totalVotes} vote{totalVotes !== 1 ? 's' : ''}
        </span>

        {isAdmin && (
          <div className="flex items-center gap-2">
            <button
              onClick={() => onToggle?.(sondage.id, !sondage.actif)}
              className={`text-xs px-3 py-1.5 rounded-lg border transition-all ${
                sondage.actif
                  ? 'border-brand-border text-brand-muted hover:text-brand-gold hover:border-brand-gold/30'
                  : 'border-green-400/20 text-green-400 hover:bg-green-400/10'
              }`}
            >
              {sondage.actif ? 'Désactiver' : 'Activer'}
            </button>
            <button
              onClick={() => onDelete?.(sondage.id)}
              className="p-1.5 rounded-lg border border-red-400/20 text-red-400 hover:bg-red-400/10 transition-all"
            >
              <RiDeleteBin6Line size={14} />
            </button>
          </div>
        )}
      </div>
    </motion.article>
  );
}
