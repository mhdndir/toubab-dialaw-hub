'use client';

import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { RiAddLine, RiNewspaperLine } from 'react-icons/ri';
import toast from 'react-hot-toast';
import PostCard from '@/components/feed/PostCard';
import PostForm from '@/components/feed/PostForm';
import Modal    from '@/components/ui/Modal';
import { PostSkeleton } from '@/components/ui/Skeleton';
import { usePosts }  from '@/hooks/usePosts';
import { useAuth  }  from '@/hooks/useAuth';
import { createPost, deletePost, updatePost } from '@/services/posts';
import type { Post, PostFormData } from '@/lib/types';

const CATEGORIES = [
  { value: '',           label: 'Tout'       },
  { value: 'actualite',  label: 'Actualités' },
  { value: 'evenement',  label: 'Événements' },
  { value: 'annonce',    label: 'Annonces'   },
  { value: 'communaute', label: 'Communauté' },
] as const;

export default function FeedPage() {
  const { user, isAdmin }       = useAuth();
  const { posts, loading, handleLike } = usePosts();

  const [filter,     setFilter]     = useState('');
  const [createOpen, setCreateOpen] = useState(false);
  const [editPost,   setEditPost]   = useState<Post | null>(null);

  const filteredPosts = filter
    ? posts.filter(p => p.category === filter)
    : posts;

  const handleCreate = useCallback(async (data: PostFormData) => {
    if (!user) return;
    await createPost(data, user.uid, user.displayName ?? 'Admin', user.photoURL ?? undefined);
    toast.success('Publication créée !');
    setCreateOpen(false);
  }, [user]);

  const handleUpdate = useCallback(async (data: PostFormData) => {
    if (!editPost) return;
    await updatePost(editPost.id, data);
    toast.success('Publication mise à jour');
    setEditPost(null);
  }, [editPost]);

  const handleDelete = useCallback(async (postId: string, imageUrl?: string) => {
    if (!confirm('Supprimer cette publication ?')) return;
    await deletePost(postId, imageUrl);
    toast.success('Publication supprimée');
  }, []);

  return (
    <div className="min-h-screen pt-24 pb-20 px-4">
      <div className="max-w-3xl mx-auto">

        {/* Page header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <RiNewspaperLine className="text-brand-teal text-xl" />
              <span className="label text-brand-teal">Fil d&apos;actualités</span>
            </div>
            <h1 className="section-title text-3xl">Publications</h1>
          </div>

          {isAdmin && (
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => setCreateOpen(true)}
              className="btn-primary"
            >
              <RiAddLine size={18} />
              Publier
            </motion.button>
          )}
        </div>

        {/* Category filter */}
        <div className="flex flex-wrap gap-2 mb-8">
          {CATEGORIES.map(cat => (
            <button
              key={cat.value}
              onClick={() => setFilter(cat.value)}
              className={`px-4 py-2 rounded-xl text-xs font-mono font-medium border transition-all duration-200 ${
                filter === cat.value
                  ? 'bg-brand-teal/10 border-brand-teal/40 text-brand-teal'
                  : 'glass border-brand-border/60 text-brand-muted hover:border-brand-muted hover:text-brand-light'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Feed */}
        {loading ? (
          <div className="space-y-6">
            {Array.from({ length: 3 }).map((_, i) => <PostSkeleton key={i} />)}
          </div>
        ) : filteredPosts.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="card p-16 text-center"
          >
            <RiNewspaperLine className="text-brand-border text-5xl mx-auto mb-4" />
            <p className="text-brand-muted font-body">
              {filter ? 'Aucune publication dans cette catégorie.' : 'Aucune publication pour le moment.'}
            </p>
          </motion.div>
        ) : (
          <AnimatePresence mode="popLayout">
            <div className="space-y-6">
              {filteredPosts.map(post => (
                <PostCard
                  key={post.id}
                  post={post}
                  userId={user?.uid}
                  isAdmin={isAdmin}
                  onLike={(id, liked) => handleLike(id, user!.uid, liked)}
                  onDelete={handleDelete}
                  onEdit={p => setEditPost(p)}
                />
              ))}
            </div>
          </AnimatePresence>
        )}
      </div>

      {/* Create modal */}
      <Modal isOpen={createOpen} onClose={() => setCreateOpen(false)} title="Nouvelle publication">
        <PostForm onSubmit={handleCreate} />
      </Modal>

      {/* Edit modal */}
      <Modal isOpen={!!editPost} onClose={() => setEditPost(null)} title="Modifier la publication">
        {editPost && (
          <PostForm
            onSubmit={handleUpdate}
            initialData={{ title: editPost.title, content: editPost.content, category: editPost.category }}
            isEdit
          />
        )}
      </Modal>
    </div>
  );
}
