import {
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  getDocs,
  query,
  orderBy,
  limit,
  startAfter,
  DocumentSnapshot,
  serverTimestamp,
  arrayUnion,
  arrayRemove,
  onSnapshot,
  Unsubscribe,
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { v4 as uuidv4 } from 'uuid';
import { db, storage } from '@/lib/firebase';
import type { Post, PostFormData } from '@/lib/types';

const COLLECTION = 'posts';
const PAGE_SIZE   = 10;

// ─── Upload image to Firebase Storage ─────────────────────────────────────

async function uploadPostImage(file: File, postId: string): Promise<string> {
  const ext      = file.name.split('.').pop();
  const filename = `${postId}.${ext}`;
  const storageRef = ref(storage, `posts/${filename}`);
  const snapshot   = await uploadBytes(storageRef, file);
  return getDownloadURL(snapshot.ref);
}

// ─── Create ────────────────────────────────────────────────────────────────

export async function createPost(
  data: PostFormData,
  authorId: string,
  authorName: string,
  authorAvatar?: string
): Promise<string> {
  const postId = uuidv4();
  let imageUrl: string | undefined;

  if (data.image) {
    imageUrl = await uploadPostImage(data.image, postId);
  }

  const docRef = await addDoc(collection(db, COLLECTION), {
    title:       data.title,
    content:     data.content,
    imageUrl:    imageUrl ?? null,
    category:    data.category,
    authorId,
    authorName,
    authorAvatar: authorAvatar ?? null,
    likes:        [],
    createdAt:   serverTimestamp(),
    updatedAt:   serverTimestamp(),
  });

  return docRef.id;
}

// ─── Read (paginated) ──────────────────────────────────────────────────────

export async function getPosts(
  lastDoc?: DocumentSnapshot
): Promise<{ posts: Post[]; lastDoc: DocumentSnapshot | null }> {
  let q = query(
    collection(db, COLLECTION),
    orderBy('createdAt', 'desc'),
    limit(PAGE_SIZE)
  );

  if (lastDoc) {
    q = query(
      collection(db, COLLECTION),
      orderBy('createdAt', 'desc'),
      startAfter(lastDoc),
      limit(PAGE_SIZE)
    );
  }

  const snap  = await getDocs(q);
  const posts = snap.docs.map(d => ({ id: d.id, ...d.data() } as Post));
  const last  = snap.docs.length > 0 ? snap.docs[snap.docs.length - 1] : null;

  return { posts, lastDoc: last };
}

// ─── Real-time feed subscription ──────────────────────────────────────────

export function subscribeToRecentPosts(
  callback: (posts: Post[]) => void
): Unsubscribe {
  const q = query(
    collection(db, COLLECTION),
    orderBy('createdAt', 'desc'),
    limit(20)
  );

  return onSnapshot(q, snap => {
    const posts = snap.docs.map(d => ({ id: d.id, ...d.data() } as Post));
    callback(posts);
  });
}

// ─── Update ────────────────────────────────────────────────────────────────

export async function updatePost(
  id: string,
  data: Partial<PostFormData>
): Promise<void> {
  const docRef = doc(db, COLLECTION, id);
  await updateDoc(docRef, {
    ...data,
    updatedAt: serverTimestamp(),
  });
}

// ─── Delete ────────────────────────────────────────────────────────────────

export async function deletePost(id: string, imageUrl?: string): Promise<void> {
  if (imageUrl) {
    try {
      const imgRef = ref(storage, imageUrl);
      await deleteObject(imgRef);
    } catch {
      // Image may not exist — ignore
    }
  }
  await deleteDoc(doc(db, COLLECTION, id));
}

// ─── Like / Unlike ─────────────────────────────────────────────────────────

export async function toggleLike(postId: string, userId: string, liked: boolean): Promise<void> {
  const docRef = doc(db, COLLECTION, postId);
  await updateDoc(docRef, {
    likes: liked ? arrayUnion(userId) : arrayRemove(userId),
  });
}
