'use client';

import { useEffect } from 'react';
import { useRouter  } from 'next/navigation';
import { motion     } from 'framer-motion';
import { RiShieldCheckLine } from 'react-icons/ri';
import { useAuth } from '@/hooks/useAuth';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const { user, isAdmin, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !isAdmin) {
      router.replace('/admin/login');
    }
  }, [loading, isAdmin, router]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-full border-2 border-brand-teal/30 border-t-brand-teal animate-spin" />
          <span className="text-brand-muted text-sm font-mono">Vérification…</span>
        </div>
      </div>
    );
  }

  if (!isAdmin) return null;

  return (
    <div className="min-h-screen">
      {/* Admin top bar */}
      <div className="fixed top-16 left-0 right-0 z-40 px-4 py-2">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-brand-teal/20 text-xs font-mono text-brand-teal"
          >
            <RiShieldCheckLine size={13} />
            Mode administrateur · {user?.email}
          </motion.div>
        </div>
      </div>

      <div className="pt-28">{children}</div>
    </div>
  );
}
