'use client';

import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { RiImageAddLine, RiCloseLine, RiSendPlaneLine } from 'react-icons/ri';
import toast from 'react-hot-toast';
import type { PostFormData, Post } from '@/lib/types';

const CATEGORIES: { value: Post['category']; label: string }[] = [
  { value: 'actualite',  label: 'Actualité'   },
  { value: 'evenement',  label: 'Événement'   },
  { value: 'annonce',    label: 'Annonce'      },
  { value: 'communaute', label: 'Communauté'  },
];

interface PostFormProps {
  onSubmit:   (data: PostFormData) => Promise<void>;
  initialData?: Partial<PostFormData>;
  isEdit?:    boolean;
}

export default function PostForm({ onSubmit, initialData, isEdit }: PostFormProps) {
  const [title,    setTitle]    = useState(initialData?.title    ?? '');
  const [content,  setContent]  = useState(initialData?.content  ?? '');
  const [category, setCategory] = useState<Post['category']>(initialData?.category ?? 'actualite');
  const [image,    setImage]    = useState<File | null>(null);
  const [preview,  setPreview]  = useState<string | null>(null);
  const [loading,  setLoading]  = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Image trop volumineuse (max 5 Mo)');
      return;
    }
    setImage(file);
    const reader = new FileReader();
    reader.onload = () => setPreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) {
      toast.error('Titre et contenu requis');
      return;
    }

    setLoading(true);
    try {
      await onSubmit({ title: title.trim(), content: content.trim(), category, image: image ?? undefined });
      if (!isEdit) {
        setTitle('');
        setContent('');
        setImage(null);
        setPreview(null);
        setCategory('actualite');
      }
    } catch (err: any) {
      toast.error(err.message ?? 'Erreur lors de la publication');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {/* Category */}
      <div>
        <label className="label">Catégorie</label>
        <div className="flex flex-wrap gap-2">
          {CATEGORIES.map(cat => (
            <button
              key={cat.value}
              type="button"
              onClick={() => setCategory(cat.value)}
              className={`px-4 py-2 rounded-lg text-xs font-mono font-medium border transition-all duration-200 ${
                category === cat.value
                  ? 'bg-brand-teal/10 border-brand-teal/40 text-brand-teal'
                  : 'bg-brand-dark border-brand-border text-brand-muted hover:border-brand-muted'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Title */}
      <div>
        <label className="label" htmlFor="post-title">Titre</label>
        <input
          id="post-title"
          type="text"
          value={title}
          onChange={e => setTitle(e.target.value)}
          placeholder="Titre de la publication"
          className="input-field"
          maxLength={120}
          required
        />
      </div>

      {/* Content */}
      <div>
        <label className="label" htmlFor="post-content">Contenu</label>
        <textarea
          id="post-content"
          value={content}
          onChange={e => setContent(e.target.value)}
          placeholder="Rédigez votre message..."
          rows={5}
          className="input-field resize-none"
          maxLength={2000}
          required
        />
        <p className="text-right text-xs text-brand-muted mt-1 font-mono">{content.length}/2000</p>
      </div>

      {/* Image upload */}
      <div>
        <label className="label">Image (optionnel)</label>
        {preview ? (
          <div className="relative rounded-xl overflow-hidden h-40 group">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={preview} alt="Aperçu" className="w-full h-full object-cover" />
            <button
              type="button"
              onClick={() => { setImage(null); setPreview(null); }}
              className="absolute top-3 right-3 w-7 h-7 rounded-full bg-brand-dark/80 flex items-center justify-center text-white hover:bg-red-500/80 transition-colors"
            >
              <RiCloseLine size={14} />
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="w-full h-32 rounded-xl border-2 border-dashed border-brand-border hover:border-brand-teal/40 flex flex-col items-center justify-center gap-2 text-brand-muted hover:text-brand-teal transition-all duration-200"
          >
            <RiImageAddLine size={24} />
            <span className="text-xs font-body">Ajouter une image · max 5 Mo</span>
          </button>
        )}
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleImageChange}
        />
      </div>

      {/* Submit */}
      <motion.button
        type="submit"
        disabled={loading}
        whileTap={{ scale: 0.97 }}
        className="btn-primary w-full justify-center disabled:opacity-60 disabled:cursor-not-allowed"
      >
        {loading ? (
          <span className="flex items-center gap-2">
            <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
            </svg>
            Publication…
          </span>
        ) : (
          <>
            <RiSendPlaneLine size={16} />
            {isEdit ? 'Mettre à jour' : 'Publier'}
          </>
        )}
      </motion.button>
    </form>
  );
}
