# 🌊 Toubab Dialaw Hub

> Plateforme digitale de la commune de Toubab Dialaw, Sénégal.

![Next.js](https://img.shields.io/badge/Next.js-14-black?style=flat-square&logo=next.js)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue?style=flat-square&logo=typescript)
![Firebase](https://img.shields.io/badge/Firebase-10-orange?style=flat-square&logo=firebase)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-3-38bdf8?style=flat-square&logo=tailwindcss)

---

## 📋 Présentation

Toubab Dialaw Hub est une plateforme web complète qui réunit :

- **📰 Fil d'actualités** — publications communales avec images et catégories
- **🏡 Marketplace** — annonces de terrains, maisons et services locaux
- **📊 Sondages** — votes citoyens avec résultats en temps réel
- **🔐 Dashboard Admin** — gestion sécurisée de tout le contenu

---

## 🛠 Stack technique

| Couche       | Technologie                         |
|--------------|-------------------------------------|
| Framework    | Next.js 14 (App Router)             |
| Langage      | TypeScript                          |
| Styling      | Tailwind CSS                        |
| Animations   | Framer Motion                       |
| Backend      | Firebase (Auth + Firestore + Storage) |
| Déploiement  | Vercel                              |

---

## 🚀 Installation

### 1. Cloner et installer

```bash
git clone https://github.com/votre-org/toubab-dialaw-hub.git
cd toubab-dialaw-hub
npm install
```

### 2. Configurer Firebase

1. Créez un projet sur [Firebase Console](https://console.firebase.google.com)
2. Activez **Authentication** → Email/Password
3. Créez une base **Firestore** (mode production)
4. Activez **Storage**
5. Dans Paramètres du projet → Vos applications → Web → Copier la config

### 3. Variables d'environnement

```bash
cp .env.local.example .env.local
```

Remplissez `.env.local` :

```env
NEXT_PUBLIC_FIREBASE_API_KEY=xxx
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=xxx.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=xxx
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=xxx.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=xxx
NEXT_PUBLIC_FIREBASE_APP_ID=xxx
NEXT_PUBLIC_ADMIN_EMAIL=admin@toubabdialaw.sn
```

### 4. Créer le compte admin

Dans Firebase Console → Authentication → Ajouter un utilisateur :
- **Email** : `admin@toubabdialaw.sn` (ou celui défini dans `NEXT_PUBLIC_ADMIN_EMAIL`)
- **Mot de passe** : de votre choix (min 8 caractères)

### 5. Déployer les règles Firestore & Storage

```bash
npm install -g firebase-tools
firebase login
firebase use --add   # sélectionnez votre projet
firebase deploy --only firestore:rules,storage
```

### 6. Lancer en développement

```bash
npm run dev
```

Ouvrez [http://localhost:3000](http://localhost:3000)

---

## 📁 Structure du projet

```
toubab-dialaw-hub/
├── app/
│   ├── layout.tsx          # Root layout (fonts, Navbar, Footer, Toaster)
│   ├── page.tsx            # Landing page
│   ├── feed/page.tsx       # Fil d'actualités
│   ├── annonces/page.tsx   # Marketplace
│   ├── sondages/page.tsx   # Sondages citoyens
│   └── admin/
│       ├── layout.tsx      # Guard d'authentification admin
│       ├── page.tsx        # Dashboard admin
│       └── login/page.tsx  # Page de connexion
│
├── components/
│   ├── layout/             # Navbar, Footer
│   ├── landing/            # Hero, Features, Stats
│   ├── feed/               # PostCard, PostForm
│   ├── annonces/           # AnnonceCard, AnnonceForm, AnnonceFilters
│   ├── sondages/           # SondageCard, SondageForm
│   └── ui/                 # Modal, Skeleton
│
├── hooks/                  # useAuth, usePosts, useAnnonces, useSondages
├── services/               # posts.ts, annonces.ts, sondages.ts (Firebase CRUD)
├── lib/
│   ├── firebase.ts         # Initialisation Firebase (singleton)
│   └── types.ts            # Interfaces TypeScript
│
├── firestore.rules         # Règles de sécurité Firestore
├── storage.rules           # Règles de sécurité Storage
├── firestore.indexes.json  # Index Firestore
├── vercel.json             # Configuration Vercel
└── .env.local.example      # Template variables d'environnement
```

---

## 🚢 Déploiement Vercel

```bash
# Via CLI
npm install -g vercel
vercel --prod

# Ou via l'interface Vercel.com
# Importez votre repo GitHub → ajoutez les variables d'env → Deploy
```

---

## 🔐 Sécurité

- **Firestore Rules** : lecture publique, écriture réservée à l'admin ; les utilisateurs authentifiés peuvent uniquement voter (modifier le tableau `likes` / `options`)
- **Admin check** : basé sur l'email Firebase (`NEXT_PUBLIC_ADMIN_EMAIL`)
- **Validation** : côté client (formulaires) et côté Firestore (rules)
- **Images** : limitées à 5 Mo, types MIME vérifiés

---

## 🎨 Design

- **Palette** : Navy `#070E1B` · Teal `#00D4C8` · Gold `#F5C842`
- **Polices** : Syne (display) + DM Sans (corps)
- **Style** : Glassmorphism + Dark mode natif + Animations Framer Motion
- **Responsive** : Mobile-first, parfaitement adapté sur tous les écrans

---

## 📄 Licence

MIT — Libre d'utilisation pour la commune de Toubab Dialaw.
