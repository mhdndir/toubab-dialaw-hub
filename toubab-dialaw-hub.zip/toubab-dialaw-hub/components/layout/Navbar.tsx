'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { HiMenu, HiX } from 'react-icons/hi';
import { RiMapPin2Fill } from 'react-icons/ri';

const navLinks = [
  { href: '/feed',      label: 'Actualités' },
  { href: '/annonces',  label: 'Annonces'   },
  { href: '/sondages',  label: 'Sondages'   },
];

export default function Navbar() {
  const pathname     = usePathname();
  const [scrolled,   setScrolled]   = useState(false);
  const [menuOpen,   setMenuOpen]   = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handler, { passive: true });
    return () => window.removeEventListener('scroll', handler);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [pathname]);

  return (
    <motion.header
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'glass border-b border-brand-border/60 shadow-card'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group">
          <div className="w-8 h-8 rounded-lg bg-brand-teal/10 border border-brand-teal/30 flex items-center justify-center group-hover:bg-brand-teal/20 transition-colors">
            <RiMapPin2Fill className="text-brand-teal text-lg" />
          </div>
          <span className="font-display font-bold text-base text-white tracking-tight">
            TOUBAB DIALAW <span className="text-brand-teal">HUB</span>
          </span>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-1">
          {navLinks.map(link => (
            <Link
              key={link.href}
              href={link.href}
              className={`relative px-4 py-2 rounded-lg font-body text-sm transition-colors duration-200 ${
                pathname.startsWith(link.href)
                  ? 'text-brand-teal'
                  : 'text-brand-light hover:text-white'
              }`}
            >
              {pathname.startsWith(link.href) && (
                <motion.span
                  layoutId="nav-pill"
                  className="absolute inset-0 bg-brand-teal/10 border border-brand-teal/20 rounded-lg"
                  transition={{ type: 'spring', bounce: 0.2, duration: 0.5 }}
                />
              )}
              <span className="relative">{link.label}</span>
            </Link>
          ))}
        </nav>

        {/* CTA */}
        <div className="hidden md:flex items-center gap-3">
          <Link href="/admin" className="btn-secondary text-xs py-2 px-4">
            Admin
          </Link>
        </div>

        {/* Mobile menu button */}
        <button
          onClick={() => setMenuOpen(v => !v)}
          className="md:hidden btn-ghost p-2 rounded-lg"
          aria-label="Menu"
        >
          {menuOpen ? <HiX size={20} /> : <HiMenu size={20} />}
        </button>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="md:hidden overflow-hidden glass border-t border-brand-border/60"
          >
            <nav className="px-4 py-4 flex flex-col gap-1">
              {navLinks.map(link => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`px-4 py-3 rounded-xl font-body text-sm transition-colors ${
                    pathname.startsWith(link.href)
                      ? 'bg-brand-teal/10 text-brand-teal border border-brand-teal/20'
                      : 'text-brand-light hover:bg-brand-border/40 hover:text-white'
                  }`}
                >
                  {link.label}
                </Link>
              ))}
              <Link
                href="/admin"
                className="mt-2 btn-secondary text-sm justify-center"
              >
                Espace Admin
              </Link>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
