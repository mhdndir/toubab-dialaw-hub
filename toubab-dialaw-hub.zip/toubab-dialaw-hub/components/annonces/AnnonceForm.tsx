'use client';

import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { RiImageAddLine, RiCloseLine, RiSendPlaneLine } from 'react-icons/ri';
import toast from 'react-hot-toast';
import type { AnnonceFormData, Annonce } from '@/lib/types';

const TYPES: { value: Annonce['type']; label: string }[] = [
  { value: 'terrain',     label: 'Terrain'     },
  { value: 'maison',      label: 'Maison'       },
  { value: 'appartement', label: 'Appartement'  },
  { value: 'service',     label: 'Service'      },
  { value: 'commerce',    label: 'Commerce'     },
];

interface AnnonceFormProps {
  onSubmit: (data: AnnonceFormData) => Promise<void>;
}

export default function AnnonceForm({ onSubmit }: AnnonceFormProps) {
  const [form, setForm] = useState<Omit<AnnonceFormData, 'images'>>({
    title: '', description: '', prix: 0, surface: undefined,
    type: 'terrain', contact: '', localite: '',
  });
  const [previews, setPreviews] = useState<string[]>([]);
  const [files,    setFiles]    = useState<FileList | null>(null);
  const [loading,  setLoading]  = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const set = (key: keyof typeof form, value: unknown) =>
    setForm(prev => ({ ...prev, [key]: value }));

  const handleImages = (e: React.ChangeEvent<HTMLInputElement>) => {
    const list = e.target.files;
    if (!list) return;
    setFiles(list);
    const newPreviews: string[] = [];
    Array.from(list).slice(0, 4).forEach(file => {
      const reader = new FileReader();
      reader.onload = () => newPreviews.push(reader.result as string);
      reader.readAsDataURL(file);
    });
    setTimeout(() => setPreviews([...newPreviews]), 200);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title || !form.description || form.prix <= 0) {
      toast.error('Titre, description et prix requis');
      return;
    }
    setLoading(true);
    try {
      await onSubmit({ ...form, images: files ?? undefined });
      setForm({ title: '', description: '', prix: 0, surface: undefined, type: 'terrain', contact: '', localite: '' });
      setPreviews([]);
      setFiles(null);
    } catch (err: any) {
      toast.error(err.message ?? 'Erreur');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {/* Type */}
      <div>
        <label className="label">Type d&apos;annonce</label>
        <div className="flex flex-wrap gap-2">
          {TYPES.map(t => (
            <button
              key={t.value}
              type="button"
              onClick={() => set('type', t.value)}
              className={`px-4 py-2 rounded-lg text-xs font-mono border transition-all ${
                form.type === t.value
                  ? 'bg-brand-teal/10 border-brand-teal/40 text-brand-teal'
                  : 'bg-brand-dark border-brand-border text-brand-muted hover:border-brand-muted'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="label">Titre</label>
        <input type="text" value={form.title} onChange={e => set('title', e.target.value)}
          placeholder="Ex: Terrain 200m² à Toubab Dialaw" className="input-field" required />
      </div>

      <div>
        <label className="label">Description</label>
        <textarea rows={4} value={form.description} onChange={e => set('description', e.target.value)}
          placeholder="Décrivez votre bien ou service..." className="input-field resize-none" required />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="label">Prix (FCFA)</label>
          <input type="number" value={form.prix || ''} onChange={e => set('prix', Number(e.target.value))}
            placeholder="0" min="0" className="input-field" required />
        </div>
        <div>
          <label className="label">Surface (m²)</label>
          <input type="number" value={form.surface || ''} onChange={e => set('surface', Number(e.target.value) || undefined)}
            placeholder="Optionnel" min="0" className="input-field" />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="label">Localité</label>
          <input type="text" value={form.localite} onChange={e => set('localite', e.target.value)}
            placeholder="Toubab Dialaw" className="input-field" />
        </div>
        <div>
          <label className="label">Contact</label>
          <input type="text" value={form.contact} onChange={e => set('contact', e.target.value)}
            placeholder="+221 7X XXX XX XX" className="input-field" />
        </div>
      </div>

      {/* Images */}
      <div>
        <label className="label">Photos (max 4)</label>
        {previews.length > 0 ? (
          <div className="grid grid-cols-4 gap-2">
            {previews.map((src, i) => (
              <div key={i} className="relative aspect-square rounded-lg overflow-hidden">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={src} alt="" className="w-full h-full object-cover" />
              </div>
            ))}
            <button type="button" onClick={() => { setPreviews([]); setFiles(null); }}
              className="aspect-square rounded-lg border-2 border-dashed border-red-400/30 flex items-center justify-center text-red-400 hover:bg-red-400/10 transition-colors">
              <RiCloseLine size={20} />
            </button>
          </div>
        ) : (
          <button type="button" onClick={() => fileRef.current?.click()}
            className="w-full h-28 rounded-xl border-2 border-dashed border-brand-border hover:border-brand-teal/40 flex flex-col items-center justify-center gap-2 text-brand-muted hover:text-brand-teal transition-all">
            <RiImageAddLine size={22} />
            <span className="text-xs">Ajouter des photos</span>
          </button>
        )}
        <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={handleImages} />
      </div>

      <motion.button type="submit" disabled={loading} whileTap={{ scale: 0.97 }}
        className="btn-primary w-full justify-center disabled:opacity-60">
        {loading ? 'Publication…' : (<><RiSendPlaneLine size={16} />Publier l&apos;annonce</>)}
      </motion.button>
    </form>
  );
}
