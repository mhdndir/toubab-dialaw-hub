'use client';

import { useRef } from 'react';
import Link from 'next/link';
import { motion, useInView } from 'framer-motion';
import {
  RiNewspaperLine, RiHome2Line, RiBarChartBoxLine,
  RiArrowRightLine, RiShieldCheckLine, RiFlashlightLine,
} from 'react-icons/ri';

const FEATURES = [
  {
    icon: RiNewspaperLine,
    color: 'teal',
    badge: '01',
    title: 'Actualités & Publications',
    description:
      'Suivez les dernières nouvelles de la commune en temps réel. Textes, photos et catégories pour rester informé.',
    href: '/feed',
    cta: 'Voir le fil',
  },
  {
    icon: RiHome2Line,
    color: 'gold',
    badge: '02',
    title: 'Marketplace Locale',
    description:
      'Terrains, maisons, services — publiez ou trouvez des annonces de qualité dans votre commune.',
    href: '/annonces',
    cta: 'Explorer les annonces',
  },
  {
    icon: RiBarChartBoxLine,
    color: 'blue',
    badge: '03',
    title: 'Sondages Citoyens',
    description:
      'Participez aux décisions collectives. Votez sur des sujets importants et consultez les résultats en direct.',
    href: '/sondages',
    cta: 'Voir les sondages',
  },
];

const QUALITIES = [
  { icon: RiShieldCheckLine,  label: 'Sécurisé',   desc: 'Données protégées par Firebase' },
  { icon: RiFlashlightLine,   label: 'Temps réel',  desc: 'Mise à jour instantanée'       },
];

const colorMap: Record<string, string> = {
  teal: 'text-brand-teal border-brand-teal/20 bg-brand-teal/10',
  gold: 'text-brand-gold border-brand-gold/20 bg-brand-gold/10',
  blue: 'text-blue-400 border-blue-400/20 bg-blue-400/10',
};

export default function Features() {
  const ref    = useRef<HTMLElement>(null);
  const inView = useInView(ref, { once: true, margin: '-10%' });

  const container = {
    hidden: {},
    visible: { transition: { staggerChildren: 0.15 } },
  };

  const item = {
    hidden:  { opacity: 0, y: 40 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] } },
  };

  return (
    <section ref={ref} className="relative py-28 px-4">
      {/* Section divider glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[400px] h-[1px] bg-gradient-to-r from-transparent via-brand-border to-transparent" />

      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="label text-brand-teal">Fonctionnalités</span>
          <h2 className="section-title mt-3 mb-4">
            Tout ce dont votre commune<br />
            <span className="text-gradient-teal">a besoin.</span>
          </h2>
          <p className="section-subtitle max-w-xl mx-auto">
            Une plateforme unique pensée pour les habitants de Toubab Dialaw.
          </p>
        </motion.div>

        {/* Feature cards */}
        <motion.div
          variants={container}
          initial="hidden"
          animate={inView ? 'visible' : 'hidden'}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16"
        >
          {FEATURES.map((feat, i) => (
            <motion.div
              key={i}
              variants={item}
              whileHover={{ y: -6, scale: 1.01 }}
              transition={{ duration: 0.25 }}
              className="card card-hover group p-7 flex flex-col"
            >
              {/* Badge + icon */}
              <div className="flex items-start justify-between mb-6">
                <div className={`w-12 h-12 rounded-xl border flex items-center justify-center ${colorMap[feat.color]}`}>
                  <feat.icon size={22} />
                </div>
                <span className="font-mono text-xs text-brand-border font-medium">{feat.badge}</span>
              </div>

              {/* Content */}
              <h3 className="font-display font-bold text-xl text-white mb-3">
                {feat.title}
              </h3>
              <p className="text-brand-muted text-sm leading-relaxed flex-1 mb-6">
                {feat.description}
              </p>

              {/* CTA */}
              <Link
                href={feat.href}
                className="inline-flex items-center gap-2 text-sm font-body text-brand-light group-hover:text-brand-teal transition-colors duration-200"
              >
                {feat.cta}
                <RiArrowRightLine className="transition-transform duration-200 group-hover:translate-x-1" />
              </Link>
            </motion.div>
          ))}
        </motion.div>

        {/* Quality badges */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          {QUALITIES.map((q, i) => (
            <div
              key={i}
              className="flex items-center gap-3 px-5 py-3 rounded-xl glass border border-brand-border/60"
            >
              <q.icon className="text-brand-teal text-lg shrink-0" />
              <div>
                <p className="text-white text-sm font-display font-semibold">{q.label}</p>
                <p className="text-brand-muted text-xs">{q.desc}</p>
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
