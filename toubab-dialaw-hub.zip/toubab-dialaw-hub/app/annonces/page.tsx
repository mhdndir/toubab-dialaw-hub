'use client';

import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { RiAddLine, RiHome2Line } from 'react-icons/ri';
import toast from 'react-hot-toast';
import AnnonceCard    from '@/components/annonces/AnnonceCard';
import AnnonceForm    from '@/components/annonces/AnnonceForm';
import AnnonceFiltersBar from '@/components/annonces/AnnonceFilters';
import Modal          from '@/components/ui/Modal';
import { AnnonceSkeleton } from '@/components/ui/Skeleton';
import { useAnnonces } from '@/hooks/useAnnonces';
import { useAuth }     from '@/hooks/useAuth';
import { createAnnonce, deleteAnnonce, updateAnnonce } from '@/services/annonces';
import type { AnnonceFilters, AnnonceFormData } from '@/lib/types';

export default function AnnoncesPage() {
  const { user, isAdmin }         = useAuth();
  const [filters, setFilters]     = useState<AnnonceFilters>({});
  const { annonces, loading }     = useAnnonces(filters);
  const [modalOpen, setModalOpen] = useState(false);

  const handleCreate = useCallback(async (data: AnnonceFormData) => {
    if (!user) return;
    await createAnnonce(data, user.uid, user.displayName ?? 'Admin');
    toast.success('Annonce publiée !');
    setModalOpen(false);
  }, [user]);

  const handleDelete = useCallback(async (id: string) => {
    if (!confirm('Supprimer cette annonce ?')) return;
    await deleteAnnonce(id);
    toast.success('Annonce supprimée');
  }, []);

  const handleToggle = useCallback(async (id: string, disponible: boolean) => {
    await updateAnnonce(id, { disponible });
    toast.success(disponible ? 'Annonce activée' : 'Annonce désactivée');
  }, []);

  return (
    <div className="min-h-screen pt-24 pb-20 px-4">
      <div className="max-w-7xl mx-auto">

        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <RiHome2Line className="text-brand-gold text-xl" />
              <span className="label text-brand-gold">Marketplace</span>
            </div>
            <h1 className="section-title text-3xl">Annonces</h1>
            <p className="text-brand-muted text-sm mt-1">
              Terrains, maisons et services à Toubab Dialaw
            </p>
          </div>

          {isAdmin && (
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => setModalOpen(true)}
              className="btn-primary"
            >
              <RiAddLine size={18} />
              Publier
            </motion.button>
          )}
        </div>

        {/* Filters */}
        <AnnonceFiltersBar onChange={setFilters} />

        {/* Count */}
        {!loading && (
          <p className="text-brand-muted text-sm font-mono mb-6">
            {annonces.length} annonce{annonces.length !== 1 ? 's' : ''} trouvée{annonces.length !== 1 ? 's' : ''}
          </p>
        )}

        {/* Grid */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => <AnnonceSkeleton key={i} />)}
          </div>
        ) : annonces.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="card p-20 text-center col-span-full"
          >
            <RiHome2Line className="text-brand-border text-5xl mx-auto mb-4" />
            <p className="text-brand-muted">Aucune annonce ne correspond à vos critères.</p>
          </motion.div>
        ) : (
          <AnimatePresence mode="popLayout">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {annonces.map((annonce, i) => (
                <motion.div
                  key={annonce.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.04 }}
                >
                  <AnnonceCard
                    annonce={annonce}
                    isAdmin={isAdmin}
                    onDelete={handleDelete}
                    onToggle={handleToggle}
                  />
                </motion.div>
              ))}
            </div>
          </AnimatePresence>
        )}
      </div>

      {/* Modal */}
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Nouvelle annonce" size="lg">
        <AnnonceForm onSubmit={handleCreate} />
      </Modal>
    </div>
  );
}
