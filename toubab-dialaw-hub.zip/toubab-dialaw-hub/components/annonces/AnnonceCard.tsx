'use client';

import { useState } from 'react';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';
import {
  RiMapPin2Line, RiRuler2Line, RiPhoneLine,
  RiDeleteBin6Line, RiCheckboxCircleLine, RiCloseCircleLine,
} from 'react-icons/ri';
import type { Annonce } from '@/lib/types';

const TYPE_LABELS: Record<Annonce['type'], string> = {
  terrain:      'Terrain',
  maison:       'Maison',
  appartement:  'Appartement',
  service:      'Service',
  commerce:     'Commerce',
};

const TYPE_COLORS: Record<Annonce['type'], string> = {
  terrain:     'text-green-400 bg-green-400/10 border-green-400/20',
  maison:      'text-brand-teal bg-brand-teal/10 border-brand-teal/20',
  appartement: 'text-blue-400 bg-blue-400/10 border-blue-400/20',
  service:     'text-purple-400 bg-purple-400/10 border-purple-400/20',
  commerce:    'text-brand-gold bg-brand-gold/10 border-brand-gold/20',
};

interface AnnonceCardProps {
  annonce:   Annonce;
  isAdmin?:  boolean;
  onDelete?: (id: string) => void;
  onToggle?: (id: string, disponible: boolean) => void;
}

export default function AnnonceCard({ annonce, isAdmin, onDelete, onToggle }: AnnonceCardProps) {
  const [imgIdx,     setImgIdx]     = useState(0);
  const [showContact, setShowContact] = useState(false);

  const timeAgo = annonce.createdAt
    ? formatDistanceToNow(annonce.createdAt.toDate(), { addSuffix: true, locale: fr })
    : '';

  const hasImages = annonce.images && annonce.images.length > 0;

  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.97 }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      className={`card card-hover group overflow-hidden ${!annonce.disponible ? 'opacity-60' : ''}`}
    >
      {/* Image gallery */}
      {hasImages ? (
        <div className="relative h-52 overflow-hidden bg-brand-dark">
          <Image
            src={annonce.images[imgIdx]}
            alt={annonce.title}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-105"
            sizes="(max-width: 768px) 100vw, 33vw"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-brand-dark/70 to-transparent" />

          {/* Image navigation */}
          {annonce.images.length > 1 && (
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
              {annonce.images.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setImgIdx(i)}
                  className={`w-1.5 h-1.5 rounded-full transition-all ${
                    i === imgIdx ? 'bg-brand-teal w-3' : 'bg-white/50'
                  }`}
                />
              ))}
            </div>
          )}

          {/* Tags overlay */}
          <div className="absolute top-3 left-3 right-3 flex items-start justify-between">
            <span className={`px-2.5 py-1 rounded-full text-xs font-mono border glass ${TYPE_COLORS[annonce.type]}`}>
              {TYPE_LABELS[annonce.type]}
            </span>
            {!annonce.disponible && (
              <span className="px-2.5 py-1 rounded-full text-xs font-mono border glass text-red-400 bg-red-400/10 border-red-400/20">
                Indisponible
              </span>
            )}
          </div>
        </div>
      ) : (
        <div className="h-20 bg-gradient-to-r from-brand-dark to-brand-card flex items-center px-5 border-b border-brand-border/40">
          <span className={`px-2.5 py-1 rounded-full text-xs font-mono border ${TYPE_COLORS[annonce.type]}`}>
            {TYPE_LABELS[annonce.type]}
          </span>
        </div>
      )}

      <div className="p-5">
        {/* Title & price */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <h3 className="font-display font-bold text-white text-base leading-snug flex-1">
            {annonce.title}
          </h3>
          <p className="font-mono font-bold text-brand-gold text-sm whitespace-nowrap shrink-0">
            {annonce.prix.toLocaleString('fr-SN')} FCFA
          </p>
        </div>

        {/* Description */}
        <p className="text-brand-muted text-sm leading-relaxed line-clamp-2 mb-4">
          {annonce.description}
        </p>

        {/* Meta */}
        <div className="flex flex-wrap gap-3 mb-4">
          <div className="flex items-center gap-1.5 text-xs text-brand-muted">
            <RiMapPin2Line className="text-brand-teal" />
            <span>{annonce.localite}</span>
          </div>
          {annonce.surface && (
            <div className="flex items-center gap-1.5 text-xs text-brand-muted">
              <RiRuler2Line className="text-brand-teal" />
              <span>{annonce.surface} m²</span>
            </div>
          )}
          <div className="ml-auto text-xs text-brand-border font-mono">{timeAgo}</div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 pt-4 border-t border-brand-border/40">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowContact(v => !v)}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl border border-brand-teal/30 text-brand-teal hover:bg-brand-teal/10 text-sm font-body transition-all duration-200"
          >
            <RiPhoneLine size={15} />
            {showContact ? annonce.contact : 'Contacter'}
          </motion.button>

          {isAdmin && (
            <>
              <button
                onClick={() => onToggle?.(annonce.id, !annonce.disponible)}
                className={`p-2.5 rounded-xl border transition-all ${
                  annonce.disponible
                    ? 'border-red-400/30 text-red-400 hover:bg-red-400/10'
                    : 'border-green-400/30 text-green-400 hover:bg-green-400/10'
                }`}
                title={annonce.disponible ? 'Marquer indisponible' : 'Marquer disponible'}
              >
                {annonce.disponible ? <RiCloseCircleLine size={18} /> : <RiCheckboxCircleLine size={18} />}
              </button>
              <button
                onClick={() => onDelete?.(annonce.id)}
                className="p-2.5 rounded-xl border border-red-400/20 text-red-400 hover:bg-red-400/10 transition-all"
              >
                <RiDeleteBin6Line size={18} />
              </button>
            </>
          )}
        </div>
      </div>
    </motion.article>
  );
}
