'use client';

import { useRef } from 'react';
import Link from 'next/link';
import { motion, useScroll, useTransform } from 'framer-motion';
import { RiArrowRightLine, RiMapPin2Fill, RiNewspaperLine, RiHome2Line, RiBarChartBoxLine } from 'react-icons/ri';

const PILLS = [
  { icon: RiNewspaperLine,   label: 'Actualités en direct'    },
  { icon: RiHome2Line,       label: 'Annonces immobilières'   },
  { icon: RiBarChartBoxLine, label: 'Sondages citoyens'       },
];

export default function Hero() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] });
  const y     = useTransform(scrollYProgress, [0, 1], ['0%', '25%']);
  const opacity = useTransform(scrollYProgress, [0, 0.7], [1, 0]);

  const containerVariants = {
    hidden: {},
    visible: { transition: { staggerChildren: 0.12, delayChildren: 0.2 } },
  };

  const itemVariants = {
    hidden:  { opacity: 0, y: 32 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] } },
  };

  return (
    <section ref={ref} className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">

      {/* Animated background orbs */}
      <motion.div style={{ y }} className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] rounded-full bg-brand-teal/5 blur-[120px] animate-float" />
        <div className="absolute bottom-1/3 right-1/4 w-[400px] h-[400px] rounded-full bg-blue-600/5 blur-[100px] animate-float" style={{ animationDelay: '-3s' }} />
        <div className="absolute top-1/2 right-1/3 w-[300px] h-[300px] rounded-full bg-brand-gold/4 blur-[80px] animate-float" style={{ animationDelay: '-5s' }} />
      </motion.div>

      {/* Rotating ring decoration */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
          className="w-[600px] h-[600px] rounded-full border border-brand-teal/5"
        />
        <motion.div
          animate={{ rotate: -360 }}
          transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
          className="absolute inset-[60px] rounded-full border border-brand-border/30"
        />
      </div>

      <motion.div
        style={{ opacity }}
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="relative z-10 text-center px-4 max-w-5xl mx-auto"
      >
        {/* Badge */}
        <motion.div variants={itemVariants} className="inline-flex items-center gap-2 mb-8">
          <div className="flex items-center gap-2 px-4 py-2 rounded-full glass border border-brand-teal/20">
            <RiMapPin2Fill className="text-brand-teal text-sm" />
            <span className="font-mono text-xs text-brand-teal tracking-widest uppercase">
              Toubab Dialaw · Sénégal
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-brand-teal animate-pulse-slow" />
          </div>
        </motion.div>

        {/* Headline */}
        <motion.h1
          variants={itemVariants}
          className="font-display font-bold text-5xl sm:text-6xl md:text-7xl lg:text-8xl leading-none tracking-tight mb-6"
        >
          <span className="text-white">La commune,</span>
          <br />
          <span className="text-gradient-teal">connectée.</span>
        </motion.h1>

        {/* Subheading */}
        <motion.p
          variants={itemVariants}
          className="text-brand-muted text-lg md:text-xl leading-relaxed max-w-2xl mx-auto mb-10"
        >
          Toubab Dialaw Hub — votre espace numérique pour l&apos;information locale,
          les annonces immobilières et la participation citoyenne.
        </motion.p>

        {/* CTA buttons */}
        <motion.div variants={itemVariants} className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
          <Link href="/feed" className="btn-primary text-sm">
            Explorer les actualités
            <RiArrowRightLine size={16} />
          </Link>
          <Link href="/annonces" className="btn-secondary text-sm">
            Voir les annonces
          </Link>
        </motion.div>

        {/* Feature pills */}
        <motion.div
          variants={itemVariants}
          className="flex flex-col sm:flex-row gap-3 justify-center"
        >
          {PILLS.map((pill, i) => (
            <motion.div
              key={i}
              whileHover={{ y: -3, scale: 1.02 }}
              transition={{ duration: 0.2 }}
              className="flex items-center gap-2 px-4 py-3 rounded-xl glass border border-brand-border/60"
            >
              <pill.icon className="text-brand-teal text-base shrink-0" />
              <span className="text-brand-light text-sm font-body">{pill.label}</span>
            </motion.div>
          ))}
        </motion.div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        style={{ opacity }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 8, 0] }}
        transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
      >
        <div className="flex flex-col items-center gap-2">
          <span className="font-mono text-[10px] text-brand-muted tracking-widest uppercase">Scroll</span>
          <div className="w-px h-12 bg-gradient-to-b from-brand-teal/40 to-transparent" />
        </div>
      </motion.div>
    </section>
  );
}
