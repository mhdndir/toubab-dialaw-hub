import type { Metadata } from 'next';
import Hero     from '@/components/landing/Hero';
import Features from '@/components/landing/Features';
import Stats    from '@/components/landing/Stats';
import Link     from 'next/link';
import { RiArrowRightLine } from 'react-icons/ri';

export const metadata: Metadata = {
  title: 'Toubab Dialaw Hub — La plateforme de la commune',
};

export default function HomePage() {
  return (
    <>
      <Hero />
      <Features />
      <Stats />

      {/* Final CTA */}
      <section className="py-24 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <div className="card border-gradient p-10 md:p-16 relative overflow-hidden">
            {/* Glow */}
            <div className="absolute inset-0 bg-gradient-radial from-brand-teal/5 to-transparent pointer-events-none" />

            <span className="label text-brand-teal">Rejoignez-nous</span>
            <h2 className="section-title mt-3 mb-4">
              Votre commune,<br />
              <span className="text-gradient-gold">votre voix.</span>
            </h2>
            <p className="section-subtitle mb-8">
              Participez à la vie de Toubab Dialaw — lisez les actualités,
              publiez vos annonces et votez sur les sujets qui comptent.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/feed" className="btn-primary">
                Commencer maintenant
                <RiArrowRightLine size={16} />
              </Link>
              <Link href="/sondages" className="btn-secondary">
                Voter sur un sondage
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
