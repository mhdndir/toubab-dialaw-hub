'use client';

import { useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { RiBarChartBoxLine } from 'react-icons/ri';
import toast from 'react-hot-toast';
import SondageCard from '@/components/sondages/SondageCard';
import { SondageSkeleton } from '@/components/ui/Skeleton';
import { useSondages } from '@/hooks/useSondages';
import { useAuth }     from '@/hooks/useAuth';
import { deleteSondage, toggleSondage } from '@/services/sondages';

export default function SondagesPage() {
  const { user, isAdmin }  = useAuth();
  const { sondages, loading } = useSondages();

  const handleDelete = useCallback(async (id: string) => {
    if (!confirm('Supprimer ce sondage ?')) return;
    await deleteSondage(id);
    toast.success('Sondage supprimé');
  }, []);

  const handleToggle = useCallback(async (id: string, actif: boolean) => {
    await toggleSondage(id, actif);
    toast.success(actif ? 'Sondage activé' : 'Sondage désactivé');
  }, []);

  const activeSondages  = sondages.filter(s => s.actif);
  const closedSondages  = sondages.filter(s => !s.actif);

  return (
    <div className="min-h-screen pt-24 pb-20 px-4">
      <div className="max-w-3xl mx-auto">

        {/* Header */}
        <div className="mb-10">
          <div className="flex items-center gap-2 mb-2">
            <RiBarChartBoxLine className="text-brand-teal text-xl" />
            <span className="label text-brand-teal">Participation citoyenne</span>
          </div>
          <h1 className="section-title text-3xl mb-2">Sondages</h1>
          <p className="text-brand-muted">
            Exprimez-vous sur les sujets qui concernent la commune.
            {!user && ' Connectez-vous pour voter.'}
          </p>
        </div>

        {loading ? (
          <div className="space-y-6">
            {Array.from({ length: 3 }).map((_, i) => <SondageSkeleton key={i} />)}
          </div>
        ) : sondages.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="card p-20 text-center"
          >
            <RiBarChartBoxLine className="text-brand-border text-5xl mx-auto mb-4" />
            <p className="text-brand-muted">Aucun sondage pour le moment.</p>
          </motion.div>
        ) : (
          <>
            {/* Active sondages */}
            {activeSondages.length > 0 && (
              <section className="mb-12">
                <h2 className="font-display font-semibold text-white text-lg mb-5 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-brand-teal animate-pulse-slow" />
                  En cours
                </h2>
                <AnimatePresence mode="popLayout">
                  <div className="space-y-6">
                    {activeSondages.map(s => (
                      <SondageCard
                        key={s.id}
                        sondage={s}
                        userId={user?.uid}
                        isAdmin={isAdmin}
                        onDelete={handleDelete}
                        onToggle={handleToggle}
                      />
                    ))}
                  </div>
                </AnimatePresence>
              </section>
            )}

            {/* Closed sondages */}
            {closedSondages.length > 0 && (
              <section>
                <h2 className="font-display font-semibold text-brand-muted text-base mb-5 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-brand-muted" />
                  Terminés / Archivés
                </h2>
                <div className="space-y-6">
                  {closedSondages.map(s => (
                    <SondageCard
                      key={s.id}
                      sondage={s}
                      userId={user?.uid}
                      isAdmin={isAdmin}
                      onDelete={handleDelete}
                      onToggle={handleToggle}
                    />
                  ))}
                </div>
              </section>
            )}
          </>
        )}
      </div>
    </div>
  );
}
