'use client';

import Link from 'next/link';
import { RiMapPin2Fill, RiGithubFill, RiTwitterXFill } from 'react-icons/ri';
import { motion } from 'framer-motion';

const links = {
  plateforme: [
    { href: '/feed',     label: 'Actualités' },
    { href: '/annonces', label: 'Annonces'   },
    { href: '/sondages', label: 'Sondages'   },
  ],
  commune: [
    { href: '#', label: 'À propos'   },
    { href: '#', label: 'Contact'    },
    { href: '#', label: 'Politique'  },
  ],
};

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="relative border-t border-brand-border/40 mt-20">
      {/* Ambient glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[1px] bg-gradient-to-r from-transparent via-brand-teal/40 to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-brand-teal/10 border border-brand-teal/30 flex items-center justify-center">
                <RiMapPin2Fill className="text-brand-teal text-lg" />
              </div>
              <span className="font-display font-bold text-base text-white">
                TOUBAB DIALAW <span className="text-brand-teal">HUB</span>
              </span>
            </Link>
            <p className="text-brand-muted text-sm leading-relaxed max-w-xs">
              La plateforme digitale de la commune de Toubab Dialaw —
              un espace de connexion, d&apos;information et de participation citoyenne.
            </p>
            <div className="flex items-center gap-3 mt-6">
              <a href="#" className="w-9 h-9 rounded-lg glass border border-brand-border flex items-center justify-center text-brand-muted hover:text-brand-teal hover:border-brand-teal/30 transition-colors">
                <RiTwitterXFill size={16} />
              </a>
              <a href="#" className="w-9 h-9 rounded-lg glass border border-brand-border flex items-center justify-center text-brand-muted hover:text-brand-teal hover:border-brand-teal/30 transition-colors">
                <RiGithubFill size={16} />
              </a>
            </div>
          </div>

          {/* Links */}
          {Object.entries(links).map(([section, items]) => (
            <div key={section}>
              <h4 className="label mb-4">{section}</h4>
              <ul className="space-y-2">
                {items.map(item => (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      className="text-brand-muted hover:text-brand-teal text-sm transition-colors duration-200"
                    >
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom */}
        <div className="pt-8 border-t border-brand-border/40 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-brand-muted text-xs font-mono">
            © {year} Toubab Dialaw Hub — Sénégal
          </p>
          <p className="text-brand-muted text-xs">
            Développé avec ♥ pour la commune
          </p>
        </div>
      </div>
    </footer>
  );
}
