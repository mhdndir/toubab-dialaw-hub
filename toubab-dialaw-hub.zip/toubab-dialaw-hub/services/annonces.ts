import {
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  getDocs,
  query,
  orderBy,
  where,
  serverTimestamp,
  onSnapshot,
  Unsubscribe,
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { v4 as uuidv4 } from 'uuid';
import { db, storage } from '@/lib/firebase';
import type { Annonce, AnnonceFormData, AnnonceFilters } from '@/lib/types';

const COLLECTION = 'annonces';

// ─── Upload multiple images ────────────────────────────────────────────────

async function uploadAnnonceImages(files: FileList, annonceId: string): Promise<string[]> {
  const uploads = Array.from(files).map(async (file, idx) => {
    const ext      = file.name.split('.').pop();
    const filename = `${annonceId}_${idx}.${ext}`;
    const imgRef   = ref(storage, `annonces/${filename}`);
    const snap     = await uploadBytes(imgRef, file);
    return getDownloadURL(snap.ref);
  });
  return Promise.all(uploads);
}

// ─── Create ────────────────────────────────────────────────────────────────

export async function createAnnonce(
  data: AnnonceFormData,
  authorId: string,
  authorName: string
): Promise<string> {
  const annonceId = uuidv4();
  let images: string[] = [];

  if (data.images && data.images.length > 0) {
    images = await uploadAnnonceImages(data.images, annonceId);
  }

  const docRef = await addDoc(collection(db, COLLECTION), {
    title:       data.title,
    description: data.description,
    prix:        data.prix,
    surface:     data.surface ?? null,
    type:        data.type,
    contact:     data.contact,
    localite:    data.localite,
    images,
    authorId,
    authorName,
    disponible:  true,
    createdAt:   serverTimestamp(),
    updatedAt:   serverTimestamp(),
  });

  return docRef.id;
}

// ─── Real-time subscription (with optional filters) ────────────────────────

export function subscribeToAnnonces(
  callback: (annonces: Annonce[]) => void,
  filters?: AnnonceFilters
): Unsubscribe {
  let q = query(collection(db, COLLECTION), orderBy('createdAt', 'desc'));

  if (filters?.type) {
    q = query(q, where('type', '==', filters.type));
  }

  return onSnapshot(q, snap => {
    let annonces = snap.docs.map(d => ({ id: d.id, ...d.data() } as Annonce));

    // Client-side price / surface filters (avoids composite indexes)
    if (filters?.prixMin !== undefined) {
      annonces = annonces.filter(a => a.prix >= filters.prixMin!);
    }
    if (filters?.prixMax !== undefined) {
      annonces = annonces.filter(a => a.prix <= filters.prixMax!);
    }
    if (filters?.surfaceMin !== undefined) {
      annonces = annonces.filter(a => (a.surface ?? 0) >= filters.surfaceMin!);
    }

    callback(annonces);
  });
}

// ─── Update ────────────────────────────────────────────────────────────────

export async function updateAnnonce(
  id: string,
  data: Partial<AnnonceFormData & { disponible: boolean }>
): Promise<void> {
  const docRef = doc(db, COLLECTION, id);
  await updateDoc(docRef, { ...data, updatedAt: serverTimestamp() });
}

// ─── Delete ────────────────────────────────────────────────────────────────

export async function deleteAnnonce(id: string): Promise<void> {
  await deleteDoc(doc(db, COLLECTION, id));
}

// ─── Static fetch (admin) ─────────────────────────────────────────────────

export async function getAllAnnonces(): Promise<Annonce[]> {
  const snap = await getDocs(
    query(collection(db, COLLECTION), orderBy('createdAt', 'desc'))
  );
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as Annonce));
}
