'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { RiAddLine, RiDeleteBin6Line, RiSendPlaneLine } from 'react-icons/ri';
import toast from 'react-hot-toast';
import type { SondageFormData } from '@/lib/types';

interface SondageFormProps {
  onSubmit: (data: SondageFormData) => Promise<void>;
}

export default function SondageForm({ onSubmit }: SondageFormProps) {
  const [question,    setQuestion]    = useState('');
  const [description, setDescription] = useState('');
  const [options,     setOptions]     = useState(['', '']);
  const [endsAt,      setEndsAt]      = useState('');
  const [loading,     setLoading]     = useState(false);

  const addOption = () => {
    if (options.length >= 6) { toast.error('Maximum 6 options'); return; }
    setOptions(prev => [...prev, '']);
  };

  const removeOption = (idx: number) => {
    if (options.length <= 2) { toast.error('Minimum 2 options'); return; }
    setOptions(prev => prev.filter((_, i) => i !== idx));
  };

  const updateOption = (idx: number, val: string) => {
    setOptions(prev => prev.map((o, i) => i === idx ? val : o));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) { toast.error('Question requise'); return; }
    const validOptions = options.filter(o => o.trim());
    if (validOptions.length < 2) { toast.error('Au moins 2 options requises'); return; }
    if (!endsAt) { toast.error('Date de fin requise'); return; }

    const endDate = new Date(endsAt);
    if (endDate <= new Date()) { toast.error('La date de fin doit être dans le futur'); return; }

    setLoading(true);
    try {
      await onSubmit({ question: question.trim(), description: description.trim() || undefined, options: validOptions, endsAt: endDate });
      setQuestion(''); setDescription(''); setOptions(['', '']); setEndsAt('');
    } catch (err: any) {
      toast.error(err.message ?? 'Erreur');
    } finally {
      setLoading(false);
    }
  };

  // Min date = tomorrow
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const minDate = tomorrow.toISOString().slice(0, 16);

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div>
        <label className="label">Question du sondage</label>
        <input type="text" value={question} onChange={e => setQuestion(e.target.value)}
          placeholder="Quelle est votre question ?" className="input-field" maxLength={200} required />
      </div>

      <div>
        <label className="label">Description (optionnel)</label>
        <textarea rows={2} value={description} onChange={e => setDescription(e.target.value)}
          placeholder="Contexte ou précisions..." className="input-field resize-none" maxLength={400} />
      </div>

      {/* Options */}
      <div>
        <label className="label">Options de réponse</label>
        <div className="space-y-2">
          <AnimatePresence>
            {options.map((opt, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                className="flex items-center gap-2"
              >
                <div className="w-6 h-6 rounded-full bg-brand-teal/10 border border-brand-teal/20 flex items-center justify-center shrink-0">
                  <span className="text-brand-teal text-xs font-mono font-bold">{i + 1}</span>
                </div>
                <input type="text" value={opt} onChange={e => updateOption(i, e.target.value)}
                  placeholder={`Option ${i + 1}`} className="input-field flex-1" maxLength={100} />
                {options.length > 2 && (
                  <button type="button" onClick={() => removeOption(i)}
                    className="p-2 text-brand-muted hover:text-red-400 transition-colors">
                    <RiDeleteBin6Line size={16} />
                  </button>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {options.length < 6 && (
          <button type="button" onClick={addOption}
            className="mt-3 flex items-center gap-2 text-sm text-brand-teal hover:text-brand-teal/80 transition-colors font-body">
            <RiAddLine size={16} />
            Ajouter une option
          </button>
        )}
      </div>

      <div>
        <label className="label">Date et heure de fin</label>
        <input type="datetime-local" value={endsAt} onChange={e => setEndsAt(e.target.value)}
          min={minDate} className="input-field" required />
      </div>

      <motion.button type="submit" disabled={loading} whileTap={{ scale: 0.97 }}
        className="btn-primary w-full justify-center disabled:opacity-60">
        {loading ? 'Création…' : (<><RiSendPlaneLine size={16} />Créer le sondage</>)}
      </motion.button>
    </form>
  );
}
