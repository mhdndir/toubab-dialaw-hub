import type { Metadata, Viewport } from 'next';
import { Syne, DM_Sans, JetBrains_Mono } from 'next/font/google';
import { Toaster } from 'react-hot-toast';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import './globals.css';

// ─── Fonts ─────────────────────────────────────────────────────────────────

const syne = Syne({
  subsets: ['latin'],
  weight: ['400', '600', '700', '800'],
  variable: '--font-syne',
  display: 'swap',
});

const dmSans = DM_Sans({
  subsets: ['latin'],
  weight: ['300', '400', '500'],
  style: ['normal', 'italic'],
  variable: '--font-dm-sans',
  display: 'swap',
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['400', '500'],
  variable: '--font-jetbrains',
  display: 'swap',
});

// ─── Metadata ──────────────────────────────────────────────────────────────

export const metadata: Metadata = {
  title: {
    default:  'Toubab Dialaw Hub — La plateforme de la commune',
    template: '%s | Toubab Dialaw Hub',
  },
  description:
    'La plateforme digitale de Toubab Dialaw — actualités, annonces immobilières, sondages citoyens et bien plus.',
  keywords: ['Toubab Dialaw', 'Sénégal', 'commune', 'actualités', 'annonces', 'immobilier'],
  authors: [{ name: 'Toubab Dialaw Hub' }],
  openGraph: {
    type:        'website',
    locale:      'fr_SN',
    siteName:    'Toubab Dialaw Hub',
    title:       'Toubab Dialaw Hub — La plateforme de la commune',
    description: 'La plateforme digitale de Toubab Dialaw.',
  },
};

export const viewport: Viewport = {
  themeColor: '#070E1B',
  colorScheme: 'dark',
};

// ─── Layout ────────────────────────────────────────────────────────────────

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="fr"
      className={`dark ${syne.variable} ${dmSans.variable} ${jetbrainsMono.variable}`}
    >
      <body className="min-h-screen bg-brand-navy font-body antialiased">
        {/* Background grid pattern */}
        <div
          className="fixed inset-0 pointer-events-none opacity-30"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%231A3050' fill-opacity='0.5'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />

        {/* Ambient glow top */}
        <div className="fixed top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] pointer-events-none">
          <div className="absolute inset-0 bg-gradient-radial from-brand-teal/8 via-transparent to-transparent rounded-full blur-3xl" />
        </div>

        <Navbar />
        <main className="relative z-10">{children}</main>
        <Footer />

        <Toaster
          position="bottom-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: '#0F1E35',
              color: '#E0EAF5',
              border: '1px solid #1A3050',
              borderRadius: '12px',
              fontFamily: 'var(--font-dm-sans)',
              fontSize: '14px',
            },
            success: { iconTheme: { primary: '#00D4C8', secondary: '#070E1B' } },
            error:   { iconTheme: { primary: '#FF4D4D', secondary: '#070E1B' } },
          }}
        />
      </body>
    </html>
  );
}
