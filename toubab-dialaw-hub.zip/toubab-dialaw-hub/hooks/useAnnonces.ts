'use client';

import { useEffect, useState, useRef } from 'react';
import type { Annonce, AnnonceFilters } from '@/lib/types';
import { subscribeToAnnonces } from '@/services/annonces';

export function useAnnonces(filters?: AnnonceFilters) {
  const [annonces, setAnnonces] = useState<Annonce[]>([]);
  const [loading,  setLoading]  = useState(true);
  const [error,    setError]    = useState<string | null>(null);
  const unsubRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    setLoading(true);

    unsubRef.current?.();

    try {
      unsubRef.current = subscribeToAnnonces(incoming => {
        setAnnonces(incoming);
        setLoading(false);
      }, filters);
    } catch (e: any) {
      setError(e.message);
      setLoading(false);
    }

    return () => {
      unsubRef.current?.();
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters?.type, filters?.prixMax, filters?.prixMin, filters?.surfaceMin]);

  return { annonces, loading, error };
}
