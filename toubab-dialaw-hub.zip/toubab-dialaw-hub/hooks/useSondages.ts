'use client';

import { useEffect, useState, useRef } from 'react';
import type { Sondage } from '@/lib/types';
import { subscribeToSondages } from '@/services/sondages';

export function useSondages() {
  const [sondages, setSondages] = useState<Sondage[]>([]);
  const [loading,  setLoading]  = useState(true);
  const [error,    setError]    = useState<string | null>(null);
  const unsubRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    setLoading(true);
    try {
      unsubRef.current = subscribeToSondages(incoming => {
        setSondages(incoming);
        setLoading(false);
      });
    } catch (e: any) {
      setError(e.message);
      setLoading(false);
    }

    return () => {
      unsubRef.current?.();
    };
  }, []);

  return { sondages, loading, error };
}
