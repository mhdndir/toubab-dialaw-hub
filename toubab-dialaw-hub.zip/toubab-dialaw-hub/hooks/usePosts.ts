'use client';

import { useEffect, useState, useCallback, useRef } from 'react';
import type { Post } from '@/lib/types';
import { subscribeToRecentPosts, toggleLike } from '@/services/posts';

export function usePosts() {
  const [posts,   setPosts]   = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState<string | null>(null);
  const unsubRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    setLoading(true);
    try {
      unsubRef.current = subscribeToRecentPosts(incoming => {
        setPosts(incoming);
        setLoading(false);
      });
    } catch (e: any) {
      setError(e.message);
      setLoading(false);
    }

    return () => {
      unsubRef.current?.();
    };
  }, []);

  const handleLike = useCallback(async (postId: string, userId: string, liked: boolean) => {
    try {
      await toggleLike(postId, userId, liked);
    } catch (e: any) {
      setError(e.message);
    }
  }, []);

  return { posts, loading, error, handleLike };
}
