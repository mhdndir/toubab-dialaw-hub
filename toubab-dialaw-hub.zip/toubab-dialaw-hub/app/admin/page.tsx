'use client';

import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  RiNewspaperLine, RiHome2Line, RiBarChartBoxLine,
  RiAddLine, RiLogoutBoxLine, RiPulseLine,
} from 'react-icons/ri';
import toast from 'react-hot-toast';
import PostCard    from '@/components/feed/PostCard';
import PostForm    from '@/components/feed/PostForm';
import AnnonceCard from '@/components/annonces/AnnonceCard';
import AnnonceForm from '@/components/annonces/AnnonceForm';
import SondageCard from '@/components/sondages/SondageCard';
import SondageForm from '@/components/sondages/SondageForm';
import Modal       from '@/components/ui/Modal';
import { PostSkeleton, AnnonceSkeleton, SondageSkeleton } from '@/components/ui/Skeleton';
import { useAuth }     from '@/hooks/useAuth';
import { usePosts }    from '@/hooks/usePosts';
import { useAnnonces } from '@/hooks/useAnnonces';
import { useSondages } from '@/hooks/useSondages';
import { createPost, deletePost } from '@/services/posts';
import { createAnnonce, deleteAnnonce, updateAnnonce } from '@/services/annonces';
import { createSondage, deleteSondage, toggleSondage } from '@/services/sondages';
import type { PostFormData, AnnonceFormData, SondageFormData } from '@/lib/types';

type Tab = 'overview' | 'posts' | 'annonces' | 'sondages';

const TABS: { key: Tab; label: string; icon: React.ElementType }[] = [
  { key: 'overview',  label: 'Vue d\'ensemble', icon: RiPulseLine         },
  { key: 'posts',     label: 'Publications',    icon: RiNewspaperLine     },
  { key: 'annonces',  label: 'Annonces',        icon: RiHome2Line         },
  { key: 'sondages',  label: 'Sondages',        icon: RiBarChartBoxLine   },
];

export default function AdminDashboardPage() {
  const { user, signOut }              = useAuth();
  const { posts,    loading: lPosts }  = usePosts();
  const { annonces, loading: lAnn   }  = useAnnonces();
  const { sondages, loading: lSond  }  = useSondages();

  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const [modal, setModal]         = useState<'post' | 'annonce' | 'sondage' | null>(null);

  /* ── Posts ── */
  const handleCreatePost = useCallback(async (data: PostFormData) => {
    if (!user) return;
    await createPost(data, user.uid, user.displayName ?? 'Admin', user.photoURL ?? undefined);
    toast.success('Publication créée'); setModal(null);
  }, [user]);

  const handleDeletePost = useCallback(async (id: string, imageUrl?: string) => {
    if (!confirm('Supprimer ?')) return;
    await deletePost(id, imageUrl); toast.success('Supprimé');
  }, []);

  /* ── Annonces ── */
  const handleCreateAnnonce = useCallback(async (data: AnnonceFormData) => {
    if (!user) return;
    await createAnnonce(data, user.uid, user.displayName ?? 'Admin');
    toast.success('Annonce créée'); setModal(null);
  }, [user]);

  const handleDeleteAnnonce = useCallback(async (id: string) => {
    if (!confirm('Supprimer ?')) return;
    await deleteAnnonce(id); toast.success('Supprimé');
  }, []);

  const handleToggleAnnonce = useCallback(async (id: string, disponible: boolean) => {
    await updateAnnonce(id, { disponible }); toast.success('Mis à jour');
  }, []);

  /* ── Sondages ── */
  const handleCreateSondage = useCallback(async (data: SondageFormData) => {
    if (!user) return;
    await createSondage(data, user.uid, user.displayName ?? 'Admin');
    toast.success('Sondage créé'); setModal(null);
  }, [user]);

  const handleDeleteSondage = useCallback(async (id: string) => {
    if (!confirm('Supprimer ?')) return;
    await deleteSondage(id); toast.success('Supprimé');
  }, []);

  const handleToggleSondage = useCallback(async (id: string, actif: boolean) => {
    await toggleSondage(id, actif); toast.success('Mis à jour');
  }, []);

  const stats = [
    { label: 'Publications', value: posts.length,    icon: RiNewspaperLine,   color: 'text-blue-400'   },
    { label: 'Annonces',     value: annonces.length,  icon: RiHome2Line,       color: 'text-brand-gold' },
    { label: 'Sondages',     value: sondages.length,  icon: RiBarChartBoxLine, color: 'text-brand-teal' },
    { label: 'Votes totaux', value: sondages.reduce((s, so) => s + so.options.reduce((a, o) => a + o.votes.length, 0), 0), icon: RiPulseLine, color: 'text-purple-400' },
  ];

  return (
    <div className="min-h-screen pb-20 px-4">
      <div className="max-w-7xl mx-auto">

        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-display font-bold text-3xl text-white mb-1">Dashboard</h1>
            <p className="text-brand-muted text-sm">Bienvenue, {user?.displayName ?? user?.email}</p>
          </div>
          <button onClick={() => { signOut(); toast.success('Déconnecté'); }}
            className="btn-ghost flex items-center gap-2 text-red-400 hover:text-red-300 hover:bg-red-400/10">
            <RiLogoutBoxLine size={16} />
            Déconnexion
          </button>
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap gap-2 mb-8">
          {TABS.map(tab => (
            <button key={tab.key} onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-body border transition-all duration-200 ${
                activeTab === tab.key
                  ? 'bg-brand-teal/10 border-brand-teal/40 text-brand-teal'
                  : 'glass border-brand-border/60 text-brand-muted hover:text-brand-light'
              }`}>
              <tab.icon size={15} />
              {tab.label}
            </button>
          ))}
        </div>

        {/* OVERVIEW */}
        <AnimatePresence mode="wait">
          {activeTab === 'overview' && (
            <motion.div key="overview" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              {/* Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
                {stats.map((s, i) => (
                  <motion.div key={i} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: i * 0.07 }} className="card p-5 text-center">
                    <s.icon className={`${s.color} text-2xl mx-auto mb-2`} />
                    <p className="font-display font-bold text-3xl text-white">{s.value}</p>
                    <p className="text-brand-muted text-xs mt-1">{s.label}</p>
                  </motion.div>
                ))}
              </div>

              {/* Quick actions */}
              <div>
                <h2 className="font-display font-semibold text-white mb-4">Actions rapides</h2>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {([
                    { key: 'post',    label: 'Nouvelle publication', icon: RiNewspaperLine,   color: 'text-blue-400'   },
                    { key: 'annonce', label: 'Nouvelle annonce',     icon: RiHome2Line,       color: 'text-brand-gold' },
                    { key: 'sondage', label: 'Nouveau sondage',      icon: RiBarChartBoxLine, color: 'text-brand-teal' },
                  ] as const).map(action => (
                    <button key={action.key} onClick={() => setModal(action.key)}
                      className="card p-6 text-center hover:border-brand-teal/30 transition-all group">
                      <action.icon className={`${action.color} text-3xl mx-auto mb-3 group-hover:scale-110 transition-transform`} />
                      <p className="font-display font-semibold text-white text-sm">{action.label}</p>
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {/* POSTS */}
          {activeTab === 'posts' && (
            <motion.div key="posts" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <div className="flex justify-end mb-6">
                <button onClick={() => setModal('post')} className="btn-primary">
                  <RiAddLine size={16} /> Nouvelle publication
                </button>
              </div>
              {lPosts ? (
                <div className="space-y-6">{Array.from({ length: 3 }).map((_, i) => <PostSkeleton key={i} />)}</div>
              ) : posts.length === 0 ? (
                <div className="card p-16 text-center text-brand-muted">Aucune publication.</div>
              ) : (
                <div className="space-y-6">
                  {posts.map(p => (
                    <PostCard key={p.id} post={p} userId={user?.uid} isAdmin
                      onLike={() => {}} onDelete={handleDeletePost} onEdit={() => {}} />
                  ))}
                </div>
              )}
            </motion.div>
          )}

          {/* ANNONCES */}
          {activeTab === 'annonces' && (
            <motion.div key="annonces" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <div className="flex justify-end mb-6">
                <button onClick={() => setModal('annonce')} className="btn-primary">
                  <RiAddLine size={16} /> Nouvelle annonce
                </button>
              </div>
              {lAnn ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {Array.from({ length: 3 }).map((_, i) => <AnnonceSkeleton key={i} />)}
                </div>
              ) : annonces.length === 0 ? (
                <div className="card p-16 text-center text-brand-muted">Aucune annonce.</div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {annonces.map(a => (
                    <AnnonceCard key={a.id} annonce={a} isAdmin
                      onDelete={handleDeleteAnnonce} onToggle={handleToggleAnnonce} />
                  ))}
                </div>
              )}
            </motion.div>
          )}

          {/* SONDAGES */}
          {activeTab === 'sondages' && (
            <motion.div key="sondages" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <div className="flex justify-end mb-6">
                <button onClick={() => setModal('sondage')} className="btn-primary">
                  <RiAddLine size={16} /> Nouveau sondage
                </button>
              </div>
              {lSond ? (
                <div className="space-y-6">{Array.from({ length: 3 }).map((_, i) => <SondageSkeleton key={i} />)}</div>
              ) : sondages.length === 0 ? (
                <div className="card p-16 text-center text-brand-muted">Aucun sondage.</div>
              ) : (
                <div className="space-y-6">
                  {sondages.map(s => (
                    <SondageCard key={s.id} sondage={s} userId={user?.uid} isAdmin
                      onDelete={handleDeleteSondage} onToggle={handleToggleSondage} />
                  ))}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Modals */}
      <Modal isOpen={modal === 'post'}    onClose={() => setModal(null)} title="Nouvelle publication">
        <PostForm onSubmit={handleCreatePost} />
      </Modal>
      <Modal isOpen={modal === 'annonce'} onClose={() => setModal(null)} title="Nouvelle annonce" size="lg">
        <AnnonceForm onSubmit={handleCreateAnnonce} />
      </Modal>
      <Modal isOpen={modal === 'sondage'} onClose={() => setModal(null)} title="Nouveau sondage">
        <SondageForm onSubmit={handleCreateSondage} />
      </Modal>
    </div>
  );
}
