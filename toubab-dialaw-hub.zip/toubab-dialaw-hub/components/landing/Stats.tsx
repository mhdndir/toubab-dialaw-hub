'use client';

import { useRef, useState, useEffect } from 'react';
import { motion, useInView } from 'framer-motion';

const STATS = [
  { value: 12000, suffix: '+',  label: 'Habitants',        desc: 'de la commune'         },
  { value: 100,   suffix: '%',  label: 'Open Source',      desc: 'transparent & libre'   },
  { value: 3,     suffix: '',   label: 'Modules',          desc: 'actualités, annonces, sondages' },
  { value: 24,    suffix: '/7', label: 'Disponibilité',    desc: 'accessible en continu' },
];

function Counter({ target, suffix }: { target: number; suffix: string }) {
  const [count, setCount] = useState(0);
  const ref     = useRef<HTMLSpanElement>(null);
  const inView  = useInView(ref, { once: true });

  useEffect(() => {
    if (!inView) return;
    const duration = 1800;
    const startTime = performance.now();
    const tick = (now: number) => {
      const elapsed  = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // Ease out quart
      const eased = 1 - Math.pow(1 - progress, 4);
      setCount(Math.round(eased * target));
      if (progress < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [inView, target]);

  return (
    <span ref={ref}>
      {count.toLocaleString('fr-SN')}
      {suffix}
    </span>
  );
}

export default function Stats() {
  const ref    = useRef<HTMLElement>(null);
  const inView = useInView(ref, { once: true, margin: '-10%' });

  return (
    <section ref={ref} className="relative py-24 px-4 overflow-hidden">
      {/* Background element */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-px bg-gradient-to-r from-transparent via-brand-border/60 to-transparent" />
      </div>

      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ duration: 0.5 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-6"
        >
          {STATS.map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={inView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.5, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
              className="card p-6 text-center group hover:border-brand-teal/30 transition-all duration-300"
            >
              <p className="font-display font-bold text-4xl md:text-5xl text-gradient-teal mb-2">
                <Counter target={stat.value} suffix={stat.suffix} />
              </p>
              <p className="font-display font-semibold text-white text-sm mb-1">
                {stat.label}
              </p>
              <p className="text-brand-muted text-xs">{stat.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
